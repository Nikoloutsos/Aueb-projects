gcc -Wall -pthread p3160011-p3160098-pizza1.c
./a.out 100 1000
read -p "Press enter to continue . . . "
